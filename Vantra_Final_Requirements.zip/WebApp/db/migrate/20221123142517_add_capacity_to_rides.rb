class AddCapacityToRides < ActiveRecord::Migration[7.0]
  def change
    add_column :rides, :capacity, :integer
  end
end
