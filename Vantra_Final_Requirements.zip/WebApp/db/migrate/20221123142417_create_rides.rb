class CreateRides < ActiveRecord::Migration[7.0]
  def change
    create_table :rides do |t|
      t.string :van_type
      t.string :plate_no
      t.string :driver_name
      t.datetime :departure
      t.datetime :arrival
      t.string :destination

      t.timestamps
    end
  end
end
