class Dashboard < ApplicationRecord
end
