class Booking < ApplicationRecord
end
