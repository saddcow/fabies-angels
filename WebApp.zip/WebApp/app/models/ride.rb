class Ride < ApplicationRecord
end
