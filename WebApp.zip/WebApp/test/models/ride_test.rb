require "test_helper"

class RideTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
