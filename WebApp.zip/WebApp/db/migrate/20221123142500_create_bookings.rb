class CreateBookings < ActiveRecord::Migration[7.0]
  def change
    create_table :bookings do |t|
      t.integer :seats_id
      t.string :fname
      t.string :lname
      t.string :contact_number
      t.integer :age
      t.text :address
      t.string :postalcode

      t.timestamps
    end
  end
end
