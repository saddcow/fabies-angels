# Pin npm packages by running ./bin/importmap

pin "application", preload: true
