package sample;

import javafx.scene.chart.XYChart;

public class BackEnd {
    series.getData ().add(new XYChart.Data)
}
