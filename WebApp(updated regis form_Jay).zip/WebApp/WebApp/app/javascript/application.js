// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
//* require jquery
//* require theme/bootstrap.min
//* require theme/jquery.easing.min
//* require theme/jquery.magnific-popup
//* require theme/bootstrap.min
//* require theme/scripts
//* require theme/swiper.min
//* require jquery_ujs
//* require jquery_tree


